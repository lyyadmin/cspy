from django.apps import AppConfig


class CsConfig(AppConfig):
    name = 'cs'
